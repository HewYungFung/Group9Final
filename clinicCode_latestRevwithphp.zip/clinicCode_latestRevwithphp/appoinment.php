<?php

include 'src/database.php' ;
$account = SQLiteDatabase('database/clinic.db');

if (isset($_POST['submit'])){
  // receive all of the form data
  $IC = $_POST['aIc'];
  $Name = $_POST['aName'];
  $PH = $_POST['aNum'];
  $Em = $_POST['aEmail'];
  $Ades = $_POST['aDes'];
  $Area = $_POST['location'];
  $DaT = $_POST['datetime'];

  try{
      $query = "INSERT INTO Appointment (IC,Name,PhN,Em,DoI,Area,DaT) VALUES (?,?,?,?,?,?,?)";
             $stmt = $account -> prepare ($query);
      $stmt -> execute ([$IC,$Name,$PH,$Em,$Ades,$Area,$DaT]);

    }catch(PDOException $e) {
      echo "Usuck" ;
    }
}

?>
<html lang="en" dir="ltr">

<head>
  <meta charset="utf-8">
  <title>Book an Appointment</title>
  <link href="https://fonts.googleapis.com/css2?family=Hurricane&family=League+Spartan:wght@600&family=Montserrat&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=EB+Garamond:wght@500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/styles.css">
  <script src="https://kit.fontawesome.com/cbd813adee.js" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

</head>

<body>


  <nav id="header-nav" class="navbar navbar-default">
    <font width="600px" style="font-size:80px; font-family: 'Hurricane', cursive;" color="#BB9981"> JIHL </font>
    <font width="600px" style="font-size:60px; font-family: 'Montserrat', sans-serif;" color="#000"> Clinic</font>
    <div class="container">
      <div class="navbar-header">

        <div class="logo hidden-xs">
          <a href="main.html">JIHL Clinic</a>
          <button onclick="myFunction()" class="dropbtn"> Our Services </button>
          <div id="myDropdown" class="dropdown-content">
            <a href="appoinment.php">Appoinment</a>
            <a href="covidTest.php">COVID Test</a>
            <a href="emergency.html">Emergency</a>

            <script>
              function myFunction() {
                document.getElementById("myDropdown").classList.toggle("show");
              }
              window.onclick = function(event) {
                if (!event.target.matches('.dropbtn')) {
                  var dropdowns = document.getElementsByClassName("dropdown-content");
                  var i;
                  for (i = 0; i < dropdowns.length; i++) {
                    var openDropdown = dropdowns[i];
                    if (openDropdown.classList.contains('show')) {
                      openDropdown.classList.remove('show');
                    }
                  }
                }
              }
            </script>

          </div>

          <a href="ourTeam.html">Our Team</a>
          <a href="ourPartners.html">Our Partners</a>
          <a href="aboutUs.html">About Us</a>
          <a href="login.php">Login</a>
          <a href="register.php">Register</a>


        </div>

        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#collapsable-nav" aria-expanded="false">
          <span class="sr-only">
            Toggle navigation
          </span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>

        <div class="collapse navbar-collapsed" id="collapsable-nav">

          <ul id="nav-list" class="nav
                        navbar-nav navbar-right">
            <hr>
            <li><a href="main.html">JIHL Clinic</a></li>
            <li><a href="appoinment.php">Appoinment</a></li>
            <li><a href="covidTest.php">COVID Test</a></li>
            <li><a href="emergency.html">Emergency</a></li>
            <li><a href="ourTeam.html">Our Team</a></li>
            <li><a href="ourPartners.html">Our Partners</a></li>
            <li><a href="aboutUs.html">About Us</a></li>
            <li><a href="login.php">Login</a></li>
            <li><a href="register.php">Register</a></li>
          </ul>
        </div>
      </div>
    </div>
  </nav>

  <h1>Book an Appointment</h1><br>
  <h3>Patient Details</h3><br><br>
  <div class="register">
    <form method="post">
      <label for="aIc">IC number:</label>
      <input type="text" id="aIc" name="aIc"><br><br>
      <label for="aName">Name:</label>
      <input type="text" id="aName" name="aName"><br><br>
      <label for="aNum">Phone number:</label>
      <input type="text" id="aNum" name="aNum"><br><br>
      <label for="aEmail">Email:</label>
      <input type="text" id="aEmail" name="aEmail"><br><br>
      <label for="aDes">Description of Issue :</label>
      <input type="text" id="aDes" name="aDes" size="50"><br><br>
      <label for="appoinment">Date and Time:</label>
      <input id="appoinment" type="datetime-local" name="datetime" min="2022-04-07T00:00" max="2022-04-30T16:30">
      <select id="location" name="location">
        <option value="Selangor">Selangor</option>
        <option value="Negeri Sembilan">Negeri Sembilan</option>
        <option value="Perak">Perak</option>
      </select>
      <input type="submit" value="Submit" name="submit" style="	font-family: 'League Spartan', sans-serif">
    </form>
  </div>

  <div class="footer">
    <div>
      <i class="fa-solid fa-phone"></i> Contact Us - Phone: 03-5543 1111 | <i class="fa-solid fa-envelope"></i> Email: JIHLclinic@gmail.com
    </div>
  </div>

</body>

</html>
