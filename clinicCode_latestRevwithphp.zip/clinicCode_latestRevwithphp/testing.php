<?php
include 'src/database.php' ;
echo SQLiteDatabase('database/clinic.db');
