<?php
//connect database with php
function SQLiteDatabase ($dbname){
  try {
    $connection = new PDO('sqlite:'.$dbname);
    $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    return $connection ;
  }catch(Exception $e){
    echo 'Something When wrong: ', $e->getMessage();
  }
}
?>
